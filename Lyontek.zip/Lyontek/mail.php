<?php 
$mailto=$_POST['email'];
$mailname=$_POST['name'];
$mailsub=$_POST['subject'];
$mailmsg=$_POST['message'];
require 'PHPMailer/PHPMailerAutoload.php';
$mail = new PHPMailer;
$mail->IsSMTP();
$mail->SMTPDebug = 1;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "ssl";
$mail->Host = "smtp.gmail.com";
$mail->Port     = 465;  
$mail->Username = "boopal143@gmail.com";
$mail->Password = "boojeevi@321";
	$mail->Mailer   = "smtp";
$mail->SetFrom("boopal143@gmail.com", "Lyontek");
$mail->AddReplyTo("boopal143@gmail.com", "Admin");
$mail->AddAddress($mailto);
$mail->IsHTML(true);
if(!$mail->Send())
{
echo "mail not sent";
}
else
{ 
echo "success";
}
?>