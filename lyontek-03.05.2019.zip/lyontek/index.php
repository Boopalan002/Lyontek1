<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Lyontek</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon1.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <link rel="stylesheet" href="css/swc.css">
  <style type="text/css">
    .carousel-item {
  height: 100vh;
  min-height: 350px;
  background: no-repeat center center scroll;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.display-1
{
font-size:30px;
color:white;
font-weight:bold;
border-radius:15px;
border:1px yellow solid;
background: transparent;
}
  </style>

</head>

<body>
<!--
<div id="boxes">
  <div id="dialog" class="window">
    <img src="img/lyontekzoom.png" height="580" width="580">
  </div>
  <div id="mask"></div>
</div>-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="js/swc.js"></script>



  <!--==========================
  Header
<!-- Navigation -->
<section id="intro">
<nav class="navbar navbar-expand-sm navbar-light fixed-top">
    <div class="container">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar1">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#intro">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#about">About Us</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#services">Our Infrastructure</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#features">Our Products</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#faq">Pricing</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#portfolio">Gallery</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" style="margin:10px;color:yellow;font-weight:bold;" href="#footer">Contact Us</a>
                </li>

            </ul>
        </div>
    </div>
</nav>

<header>
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('img/slide12.jpg')">
        <div class="carousel-caption d-none d-md-block" style="position:absolute;top:250px;">
          <center><h2 class="display-1 animated fadeInLeft" style="background-color: green;font-size:40px;width:800px;">Manufactures, Suppliers & Exporters</h2></center>
          <center><p class="animated fadeInDown" style="width:400px;border-radius:15px;padding:2px;background-color: #ebca34;font-size:30px;border:1px inset red;color:black;font-weight:bold;">Non Woven Bags</p></center>
           <center><p class="animated fadeInUp" style="width:400px;font-weight:bold;background-color: green;font-size:30px;border-radius:15px;padding:2px;border:1px solid yellow;">Go Green. Save World.</p></center>
        </div>
      </div>
      <!-- Slide Two - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('img/slide2.jpg')">
        <div class="carousel-caption d-none d-md-block" style="position:absolute;top:400px;">
          <center><h2 class="display-1 animated fadeInLeft" style="background-color: green;font-size:40px;width:780px;">Trusted Name in Society & Industry</h2></center>
        </div>
      </div>
      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('img/slide3.jpg')">
        <div class="carousel-caption d-none d-md-block" style="position:absolute;top:400px;">
          <center><h2 class="display-1 animated fadeInRight" style="background-color: green;font-size:40px;width:480px;">Quality is Our Motto</h2></center>
        </div>
      </div>
            <div class="carousel-item" style="background-image: url('img/slide14.jpg')">
        <div class="carousel-caption d-none d-md-block" style="position:absolute;top:400px;">
          <center><h2 class="display-1 animated fadeInLeft" style="background-color: green;font-size:40px;width:800px;">Innovation is Our Technical Success</h2></center>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>
</header>
</section><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->


  <!-- #intro -->

  <main id="main">



    <!--==========================
      About Us Section
    ============================-->
    <section id="about">

      <div class="container">
        <div class="row">

          <div class="col-lg-5 col-md-6">
            <div class="about-img">
              <img src="img/customimage1.jpg" alt="">
            </div>
          </div>

          <div class="col-lg-7 col-md-6">
            <div class="about-content">
              <h2>About Us</h2>
              <p style="text-align:justify;">Since 2017, we “Lyontek” is working as a Partnership based entity, which frequently put efforts to offer the qualitative array of products to the market. We set our chief to headquarter at Irugur Post, Coimbatore, Tamil Nadu. Our manufacturing occupation runs under the keen surveillance of our professional and our products widely rejoice amongst the customers. Due to our in-depth acquaintance of this domain, we are delivering the spectrum of products includes Non-Woven Bag and many more. We are skilled experts make sure the manufacturing of our merchandises range at a constant high level and always maintain superiority standards of the products.</p>
              <h2>Why Us</h2>
              <p style="text-align:justify;">Since formation, our firm aspires to be customer-centric and a pioneer in the marketplace. We strive to deliver accessible and competitive products to our customers at competitive price range.</p>
              <p style="text-align:justify;">Our key strengths are,</p>
              <ul>
                <li><i class="ion-android-checkmark-circle"></i> Transparent business dealings</li>
                <li><i class="ion-android-checkmark-circle"></i> Qualified and trained team of professionals</li>
                <li><i class="ion-android-checkmark-circle"></i> In-depth industry knowledge</li>
                <li><i class="ion-android-checkmark-circle"></i> Timely completion of orders</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

    </section><!-- #about -->


    <!--==========================
      Services Section
    ============================-->
    <section id="services" class="section-bg">
      <div class="container">

        <header class="section-header">
          <h3>Our Infrastructure</h3>
          <p>We have developed an ultra-modern infrastructure base at our premises to have flawless production procedure. We ensure that the installed machineries are upgraded on regular time intervals by our professionals in order to have finer quality production at faster rates. Moreover, we have segmented the facility into various units that consists of: </p>
        </header>

        <div class="row">

          <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon" style="background: #fceef3;"><i class="ion-ios-cog-outline" style="color: #ff689b;"></i></div>
              <h4 class="title"><a href="">Manufacturing unit</a></h4>
              
            </div>
          </div>
          <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon" style="background: #fff0da;"><i class="ion-thumbsup" style="color: #e98e06;"></i></div>
              <h4 class="title"><a href="">Quality Unit</a></h4>
             
            </div>
          </div>

          <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon" style="background: #e6fdfc;"><i class="ion-ios-paper-outline" style="color: #3fcdc7;"></i></div>
              <h4 class="title"><a href="">R & D</a></h4>
             
            </div>
          </div>
          <div class="col-md-6 col-lg-6 wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="box">
              <div class="icon" style="background: #eafde7;"><i class="ion-ios-home-outline" style="color:#41cf2e;"></i></div>
              <h4 class="title"><a href="">Warehouse</a></h4>
              
            </div>
          </div>

        </div>

      </div>
    </section><!-- #services -->

    <!--==========================
      Why Us Section
    ============================-->
    <!--<section id="why-us" class="wow fadeIn">
      <div class="container-fluid">
        
        <header class="section-header">
          <h3>Why choose us?</h3>
          <p>Laudem latine persequeris id sed, ex fabulas delectus quo. No vel partiendo abhorreant vituperatoribus.</p>
        </header>

        <div class="row">

          <div class="col-lg-6">
            <div class="why-us-img">
              <img src="img/why-us.jpg" alt="" class="img-fluid">
            </div>
          </div>

          <div class="col-lg-6">
            <div class="why-us-content">
              <p>Molestiae omnis numquam corrupti omnis itaque. Voluptatum quidem impedit. Odio dolorum exercitationem est error omnis repudiandae ad dolorum sit.</p>
              <p>
                Explicabo repellendus quia labore. Non optio quo ea ut ratione et quaerat. Porro facilis deleniti porro consequatur
                et temporibus. Labore est odio.

                Odio omnis saepe qui. Veniam eaque ipsum. Ea quia voluptatum quis explicabo sed nihil repellat..
              </p>

              <div class="features wow bounceInUp clearfix">
                <i class="fa fa-diamond" style="color: #f058dc;"></i>
                <h4>Corporis dolorem</h4>
                <p>Commodi quia voluptatum. Est cupiditate voluptas quaerat officiis ex alias dignissimos et ipsum. Soluta at enim modi ut incidunt dolor et.</p>
              </div>

              <div class="features wow bounceInUp clearfix">
                <i class="fa fa-object-group" style="color: #ffb774;"></i>
                <h4>Eum ut aspernatur</h4>
                <p>Molestias eius rerum iusto voluptas et ab cupiditate aut enim. Assumenda animi occaecati. Quo dolore fuga quasi autem aliquid ipsum odit. Perferendis doloremque iure nulla aut.</p>
              </div>
              
              <div class="features wow bounceInUp clearfix">
                <i class="fa fa-language" style="color: #589af1;"></i>
                <h4>Voluptates dolores</h4>
                <p>Voluptates nihil et quis omnis et eaque omnis sint aut. Ducimus dolorum aspernatur. Totam dolores ut enim ullam voluptas distinctio aut.</p>
              </div>
              
            </div>

          </div>

        </div>

      </div>

      <div class="container">
        <div class="row counters">

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up">274</span>
            <p>Clients</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up">421</span>
            <p>Projects</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up">1,364</span>
            <p>Hours Of Support</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up">18</span>
            <p>Hard Workers</p>
          </div>
  
        </div>

      </div>
    </section>-->



    <!--==========================
      Features Section
    ============================-->
    <section id="features">
      <div class="container">
         <header class="section-header">
          <h3>Our Products</h3>
          <p>Our range of products include D Cut Non Woven Color Bag, Printed W Cut Non Woven Bag, D Cut Non Woven Bag, W Cut Non Woven 100% Virgin Bag, U Cut Non Woven Color Bag and W Cut Non Woven Color Bag.</p>
        </header>

        <div class="row feature-item">
          <div class="col-lg-6 wow fadeInUp">
            <img src="img/dcutcolor.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 wow fadeInUp pt-5 pt-lg-0">
            <h4 style='color:#4fac34;'>D CUT NON WOVEN COLOR BAG</h4>
            <h5>
              <b>Approx Price: Rs 130/Kilogram</b><br>
              <b>Minimum Order Quantity: 50 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">9 x 10 - 16 x 24 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">Customized</td>
              </tr>
              <tr>
                <td style="width:200px;">Design Type</td>
                <td style="width:500px;text-align:right;">Standard</td>
              </tr>
              <tr>
                <td style="width:200px;">Handle Type</td>
                <td style="width:500px;text-align:right;">D Cut</td>
              </tr>
              <tr>
                <td style="width:300px;">Capacity (Kilogram)</td>
                <td style="text-align:right;">5 KG, 10 KG</td>
              </tr>
              <tr>
                <td style="width:200px;">Surface Finish</td>
                <td style="width:500px;text-align:right;">Matte</td>
              </tr>
              <tr>
                <td style="width:200px;">Printing</td>
                <td style="width:500px;text-align:right;">Offset</td>
              </tr>
              <tr>
                <td style="width:200px;">Thickness</td>
                <td style="width:500px;text-align:right;">60 - 100 GSM</td>
              </tr>
               <tr>
                <td style="width:200px;">Property</td>
                <td style="width:500px;text-align:right;">Recyclable, Biodegradable</td>
              </tr>
              <tr>
                <td style="width:200px;">Closure Type</td>
                <td style="width:500px;text-align:right;">Open</td>
              </tr>
              <tr>
                <td style="width:200px;">Virgin Quality</td>
                <td style="width:500px;text-align:right;">Semi-Virgin</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Printed, Plain</td>
              </tr>

            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>Our company holds immense experience in this domain and is involved in offering a wide assortment of D Cut Non Woven Color Bag.</b></h6>
          </div>
            
        </div>

        <div class="row feature-item mt-5 pt-5">
          <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
            <img src="img/wcutprint.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1">
            <h4 style='color:#4fac34;'>PRINTED W CUT NON WOVEN COLOR BAG</h4>
            <h5>
              <b>Approx Price: Rs 210/Kilogram</b><br>
              <b>Minimum Order Quantity: 50 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">8 x 9 - 22 x 26 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">Customized</td>
              </tr>
              <tr>
                <td style="width:200px;">Design Type</td>
                <td style="width:500px;text-align:right;">Standard</td>
              </tr>
              <tr>
                <td style="width:200px;">Handle Type</td>
                <td style="width:500px;text-align:right;">W Cut</td>
              </tr>
              <tr>
                <td style="width:300px;">Capacity (Kilogram)</td>
                <td style="text-align:right;">2 KG, 5 KG, 10 KG, 20 KG</td>
              </tr>
              <tr>
                <td style="width:200px;">Surface Finish</td>
                <td style="width:500px;text-align:right;">Matte</td>
              </tr>
              <tr>
                <td style="width:200px;">Printing</td>
                <td style="width:500px;text-align:right;">Offset</td>
              </tr>
              <tr>
                <td style="width:200px;">Thickness</td>
                <td style="width:500px;text-align:right;">20 - 100 GSM</td>
              </tr>
               <tr>
                <td style="width:200px;">Property</td>
                <td style="width:500px;text-align:right;">Recyclable</td>
              </tr>
              <tr>
                <td style="width:200px;">Closure Type</td>
                <td style="width:500px;text-align:right;">Open</td>
              </tr>
              <tr>
                <td style="width:200px;">Virgin Quality</td>
                <td style="width:500px;text-align:right;">Recycled</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Printed, Plain</td>
              </tr>
              <tr>
                <td style="width:200px;">Fabric</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Usage/Application</td>
                <td style="width:500px;text-align:right;">Grocery, Promotion</td>
              </tr>
            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>Our company is highly esteemed in offering Printed W Cut Non Woven Bag.</b></h6>
          </div>
        </div>

        <div class="row feature-item">
          <div class="col-lg-6 wow fadeInUp">
            <img src="img/dcutwhite.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 wow fadeInUp pt-5 pt-lg-0">
            <h4 style='color:#4fac34;'>D CUT NON WOVEN BAG</h4>
            <h5>
              <b>Approx Price: Rs 125/Kilogram</b><br>
              <b>Minimum Order Quantity: 50 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">9 x 10 - 16 x 24 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">Customized</td>
              </tr>
              <tr>
                <td style="width:200px;">Design Type</td>
                <td style="width:500px;text-align:right;">Standard</td>
              </tr>
              <tr>
                <td style="width:200px;">Handle Type</td>
                <td style="width:500px;text-align:right;">D Cut</td>
              </tr>
              <tr>
                <td style="width:300px;">Capacity (Kilogram)</td>
                <td style="text-align:right;">5 KG, 10 KG, 15 KG</td>
              </tr>
              <tr>
                <td style="width:200px;">Surface Finish</td>
                <td style="width:500px;text-align:right;">Matte</td>
              </tr>
              <tr>
                <td style="width:200px;">Printing</td>
                <td style="width:500px;text-align:right;">Offset</td>
              </tr>
              <tr>
                <td style="width:200px;">Thickness</td>
                <td style="width:500px;text-align:right;">60 - 100 GSM</td>
              </tr>
               <tr>
                <td style="width:200px;">Property</td>
                <td style="width:500px;text-align:right;">Recyclable</td>
              </tr>
              <tr>
                <td style="width:200px;">Closure Type</td>
                <td style="width:500px;text-align:right;">Open</td>
              </tr>
              <tr>
                <td style="width:200px;">Virgin Quality</td>
                <td style="width:500px;text-align:right;">100% Virgin</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Printed, Plain</td>
              </tr>
              <tr>
                <td style="width:200px;">Usage/Application</td>
                <td style="width:500px;text-align:right;">Shopping, Promotion</td>
              </tr>
            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>Banking on the skills of our qualified team of professionals, we are involved in providing D Cut Non Woven Bag.</b></h6>
          </div>
        </div>

        <div class="row feature-item mt-5 pt-5">
          <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
            <img src="img/wcutwhite.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1">
            <h4 style='color:#4fac34;'>W CUT NON WOVEN 100% VIRGIN BAG</h4>
            <h5>
              <b>Approx Price: Rs 190/Kilogram</b><br>
              <b>Minimum Order Quantity: 100 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">8 x 9 - 20 x 26 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">Customized</td>
              </tr>
              <tr>
                <td style="width:200px;">Design Type</td>
                <td style="width:500px;text-align:right;">Standard</td>
              </tr>
              <tr>
                <td style="width:200px;">Handle Type</td>
                <td style="width:500px;text-align:right;">W Cut</td>
              </tr>
              <tr>
                <td style="width:300px;">Capacity (Kilogram)</td>
                <td style="text-align:right;">1 KG, 5 KG, 10 KG</td>
              </tr>
              <tr>
                <td style="width:200px;">Surface Finish</td>
                <td style="width:500px;text-align:right;">Matte</td>
              </tr>
              <tr>
                <td style="width:200px;">Printing</td>
                <td style="width:500px;text-align:right;">Offset</td>
              </tr>
              <tr>
                <td style="width:200px;">Thickness</td>
                <td style="width:500px;text-align:right;">20 - 100 GSM</td>
              </tr>
               <tr>
                <td style="width:200px;">Property</td>
                <td style="width:500px;text-align:right;">Recyclable</td>
              </tr>
              <tr>
                <td style="width:200px;">Closure Type</td>
                <td style="width:500px;text-align:right;">Open</td>
              </tr>
              <tr>
                <td style="width:200px;">Virgin Quality</td>
                <td style="width:500px;text-align:right;">100% Virgin</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Printed, Plain</td>
              </tr>
              <tr>
                <td style="width:200px;">Fabric</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Usage/Application</td>
                <td style="width:500px;text-align:right;">Shopping, Grocery, Promotion</td>
              </tr>
            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>Leveraging the skills of our qualified team of professionals, we are instrumental in offering a wide range of W Cut Non Woven 100% Virgin Bag.</b></h6>
          </div>
        </div>

        <div class="row feature-item">
          <div class="col-lg-6 wow fadeInUp">
            <img src="img/ucutcolor.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 wow fadeInUp pt-5 pt-lg-0">
            <h4 style='color:#4fac34;'>U CUT NON WOVEN COLOR BAG</h4>
            <h5>
              <b>Approx Price: Rs 125/Kilogram</b><br>
              <b>Minimum Order Quantity: 50 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">8 x 9 - 20 x 26 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">All Colors</td>
              </tr>
              <tr>
                <td style="width:200px;">Design Type</td>
                <td style="width:500px;text-align:right;">Standard</td>
              </tr>
              <tr>
                <td style="width:200px;">Handle Type</td>
                <td style="width:500px;text-align:right;">D Cut</td>
              </tr>
              <tr>
                <td style="width:300px;">Capacity (Kilogram)</td>
                <td style="text-align:right;">1 KG, 2 KG, 5 KG</td>
              </tr>
              <tr>
                <td style="width:200px;">Surface Finish</td>
                <td style="width:500px;text-align:right;">Matte</td>
              </tr>
              <tr>
                <td style="width:200px;">Printing</td>
                <td style="width:500px;text-align:right;">Offset</td>
              </tr>
              <tr>
                <td style="width:200px;">Thickness</td>
                <td style="width:500px;text-align:right;">20 - 100 GSM</td>
              </tr>
               <tr>
                <td style="width:200px;">Property</td>
                <td style="width:500px;text-align:right;">Recyclable</td>
              </tr>
              <tr>
                <td style="width:200px;">Closure Type</td>
                <td style="width:500px;text-align:right;">Open</td>
              </tr>
              <tr>
                <td style="width:200px;">Virgin Quality</td>
                <td style="width:500px;text-align:right;">100% Virgin</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Printed, Plain</td>
              </tr>
              <tr>
                <td style="width:200px;">Usage/Application</td>
                <td style="width:500px;text-align:right;">Shopping, Promotion</td>
              </tr>
            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>We have carved a niche amongst the most trusted names in this business, engaged in offering a comprehensive range of U Cut Non Woven Color Bag.</b></h6>
          </div>
        </div>


        <div class="row feature-item mt-5 pt-5">
          <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
            <img src="img/wcutcolor.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-6 wow fadeInUp pt-4 pt-lg-0 order-2 order-lg-1">
            <h4 style='color:#4fac34;'>W CUT NON WOVEN COLOR BAG</h4>
            <h5>
              <b>Approx Price: Rs 125/Kilogram</b><br>
              <b>Minimum Order Quantity: 50 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">8 x 9 - 20 x 26 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">Customized</td>
              </tr>
              <tr>
                <td style="width:200px;">Design Type</td>
                <td style="width:500px;text-align:right;">Standard</td>
              </tr>
              <tr>
                <td style="width:200px;">Handle Type</td>
                <td style="width:500px;text-align:right;">W Cut</td>
              </tr>
              <tr>
                <td style="width:300px;">Capacity (Kilogram)</td>
                <td style="text-align:right;">1.5 KG - 15 KG</td>
              </tr>
              <tr>
                <td style="width:200px;">Surface Finish</td>
                <td style="width:500px;text-align:right;">Matte</td>
              </tr>
              <tr>
                <td style="width:200px;">Printing</td>
                <td style="width:500px;text-align:right;">Offset</td>
              </tr>
              <tr>
                <td style="width:200px;">Thickness</td>
                <td style="width:500px;text-align:right;">20 - 100 GSM</td>
              </tr>
               <tr>
                <td style="width:200px;">Property</td>
                <td style="width:500px;text-align:right;">Recyclable</td>
              </tr>
              <tr>
                <td style="width:200px;">Closure Type</td>
                <td style="width:500px;text-align:right;">Open</td>
              </tr>
              <tr>
                <td style="width:200px;">Virgin Quality</td>
                <td style="width:500px;text-align:right;">100% Virgin</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Printed, Plain</td>
              </tr>
              <tr>
                <td style="width:200px;">Fabric</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Usage/Application</td>
                <td style="width:500px;text-align:right;">Shopping, Grocery</td>
              </tr>
            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>In order to keep pace with the never-ending demands of customers, we are involved in offering a wide range of W Cut Non Woven Color Bag.</b></h6>
          </div>
        </div>


        <div class="row feature-item">
          <div class="col-lg-6 wow fadeInUp">
            <img src="img/wcutwhite1.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 wow fadeInUp pt-5 pt-lg-0">
            <h4 style='color:#4fac34;'>W CUT NON WOVEN WHITE BAG</h4>
            <h5>
              <b>Approx Price: Rs 125/Kilogram</b><br>
              <b>Minimum Order Quantity: 100 Kilogram</b>
            </h5>
            <h6 ><b>Product Details:</b></h6>
            <div class="container">
            <table cellspacing="10" cellpadding="10" class="table-responsive table-striped table-hover">
              <tr>
                <td style="width:200px;">Bag Size</td>
                <td style="width:500px;text-align:right;">10 x 12 - 20 x 24 Inches</td>
              </tr>
              <tr>
                <td style="width:200px;">Color</td>
                <td style="width:500px;text-align:right;">White</td>
              </tr>
              <tr>
                <td style="width:200px;">Material</td>
                <td style="width:500px;text-align:right;">Non Woven</td>
              </tr>
              <tr>
                <td style="width:200px;">Pattern</td>
                <td style="width:500px;text-align:right;">Plain</td>
              </tr>
            </table><br>
          </div>
            <h6 style="text-align:justify;"><b>W cut non woven white colour in 45 to 150 GSM in small, Medium, and Large sizes based on customer specific requirements.  </b></h6>
            <h6 style="text-align:justify;"><b>Single colour printing and Two colour printing can be done if customer gives coral draw designs and we can develop flex stencil for printing in offset imported printer.</b></h6>
            <h6 style="text-align:justify;"><b>Cost Rs.150 per KG for single side Rs.170 per kg for both side two colour printing. Minimum quantities for printed non woven bags should be 200 to 300kgs for one type.</b></h6>
          </div>
        </div>

      </div>
    </section><!-- #about -->

    <section id="faq" class="section-bg">
      <div class="container">
        <header class="section-header">
          <h3>Pricing List</h3>
        </header>

        <ul id="faq-list" class="wow fadeInUp">
          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq1">D CUT NON WOVEN BAG - WHITE - PRICE LIST<i class="ion-android-remove"></i></a>
            <div id="faq1" class="collapse" data-parent="#faq-list">
              <table class="table-bordered table-hover" width="100%" cellspacing="10" cellpadding="10">
                <tr style="background-color:#bfca33;">
                  <th style="width:100px;text-align:center;">GSM</th>
                  <th style="width:100px;text-align:center;">QTY in KG</th>
                  <th style="width:100px;text-align:center;">Sizes</th>
                  <th style="width:200px;text-align:center;">Base price-per kg</th>
                  <th style="width:100px;text-align:center;">GST</th>
                  <th style="width:100px;text-align:center;">Total cost per kg</th>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;" rowspan="6">60/80</td>
                  <td style="width:100px;text-align:center;">75</td>
                  <td style="width:100px;text-align:center;">10*12</td>
                  <td style="width:200px;text-align:center;">125</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">131.25</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">70</td>
                  <td style="width:100px;text-align:center;">12*14</td>
                  <td style="width:200px;text-align:center;">125</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">131.25</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">41</td>
                  <td style="width:100px;text-align:center;">13*16</td>
                  <td style="width:200px;text-align:center;">125</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">131.25</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">36</td>
                  <td style="width:100px;text-align:center;">14*18</td>
                  <td style="width:200px;text-align:center;">125</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">131.25</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">30</td>
                  <td style="width:100px;text-align:center;">16*18</td>
                  <td style="width:200px;text-align:center;">125</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">131.25</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">28</td>
                  <td style="width:100px;text-align:center;">16*20</td>
                  <td style="width:200px;text-align:center;">125</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">131.25</td>
                </tr>
              </table>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq11">D CUT NON WOVEN BAG - COLOR - PRICE LIST<i class="ion-android-remove"></i></a>
            <div id="faq11" class="collapse" data-parent="#faq-list">
              <table class="table-bordered table-hover" width="100%" cellspacing="10" cellpadding="10">
                <tr style="background-color:#bfca33;">
                  <th style="width:100px;text-align:center;">GSM</th>
                  <th style="width:100px;text-align:center;">QTY in KG</th>
                  <th style="width:100px;text-align:center;">Sizes</th>
                  <th style="width:200px;text-align:center;">Base price-per kg</th>
                  <th style="width:100px;text-align:center;">GST</th>
                  <th style="width:100px;text-align:center;">Total cost per kg</th>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;" rowspan="6">60/80</td>
                  <td style="width:100px;text-align:center;">75</td>
                  <td style="width:100px;text-align:center;">10*12</td>
                  <td style="width:200px;text-align:center;">131</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">137.55</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">70</td>
                  <td style="width:100px;text-align:center;">12*14</td>
                  <td style="width:200px;text-align:center;">131</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">137.55</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">41</td>
                  <td style="width:100px;text-align:center;">13*16</td>
                  <td style="width:200px;text-align:center;">131</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">137.55</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">36</td>
                  <td style="width:100px;text-align:center;">14*18</td>
                  <td style="width:200px;text-align:center;">131</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">137.55</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">30</td>
                  <td style="width:100px;text-align:center;">16*18</td>
                  <td style="width:200px;text-align:center;">131</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">137.55</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">28</td>
                  <td style="width:100px;text-align:center;">16*20</td>
                  <td style="width:200px;text-align:center;">131</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">137.55</td>
                </tr>
              </table>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq2">W/U CUT NON WOVEN BAG - WHITE - PRICE LIST<i class="ion-android-remove"></i></a>
            <div id="faq2" class="collapse" data-parent="#faq-list">
              <table class="table-bordered table-hover" width="100%" cellspacing="10" cellpadding="10">
                <tr style="background-color:#bfca33;">
                  <th style="width:100px;text-align:center;">GSM</th>
                  <th style="width:100px;text-align:center;">QTY in KG</th>
                  <th style="width:100px;text-align:center;">Sizes</th>
                  <th style="width:200px;text-align:center;">Base price-per kg</th>
                  <th style="width:100px;text-align:center;">GST</th>
                  <th style="width:100px;text-align:center;">Total cost per kg</th>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;" rowspan="6">45/50</td>
                  <td style="width:100px;text-align:center;">135</td>
                  <td style="width:100px;text-align:center;">10*12</td>
                  <td style="width:200px;text-align:center;">120</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">126</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">120-130</td>
                  <td style="width:100px;text-align:center;">12*14</td>
                  <td style="width:200px;text-align:center;">120</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">126</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">71</td>
                  <td style="width:100px;text-align:center;">13*16</td>
                  <td style="width:200px;text-align:center;">120</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">126</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">50</td>
                  <td style="width:100px;text-align:center;">16*20</td>
                  <td style="width:200px;text-align:center;">120</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">126</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">39</td>
                  <td style="width:100px;text-align:center;">17*23</td>
                  <td style="width:200px;text-align:center;">120</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">126</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">33</td>
                  <td style="width:100px;text-align:center;">20*24</td>
                  <td style="width:200px;text-align:center;">120</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">126</td>
                </tr>
              </table>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq3">W/U CUT NON WOVEN BAG - COLOR - PRICE LIST<i class="ion-android-remove"></i></a>
            <div id="faq3" class="collapse" data-parent="#faq-list">
              <table class="table-bordered table-hover" width="100%" cellspacing="10" cellpadding="10">
                <tr style="background-color:#bfca33;">
                  <th style="width:100px;text-align:center;">GSM</th>
                  <th style="width:100px;text-align:center;">QTY in KG</th>
                  <th style="width:100px;text-align:center;">Sizes</th>
                  <th style="width:200px;text-align:center;">Base price-per kg</th>
                  <th style="width:100px;text-align:center;">GST</th>
                  <th style="width:100px;text-align:center;">Total cost per kg</th>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;" rowspan="6">45/50</td>
                  <td style="width:100px;text-align:center;">135</td>
                  <td style="width:100px;text-align:center;">10*12</td>
                  <td style="width:200px;text-align:center;">126</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">132.30</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">120-130</td>
                  <td style="width:100px;text-align:center;">12*14</td>
                  <td style="width:200px;text-align:center;">126</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">132.30</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">71</td>
                  <td style="width:100px;text-align:center;">13*16</td>
                  <td style="width:200px;text-align:center;">126</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">132.30</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">50</td>
                  <td style="width:100px;text-align:center;">16*20</td>
                  <td style="width:200px;text-align:center;">126</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">132.30</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">39</td>
                  <td style="width:100px;text-align:center;">17*23</td>
                  <td style="width:200px;text-align:center;">126</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">132.30</td>
                </tr>
                <tr>
                  <td style="width:100px;text-align:center;">33</td>
                  <td style="width:100px;text-align:center;">20*24</td>
                  <td style="width:200px;text-align:center;">126</td>
                  <td style="width:100px;text-align:center;">5%</td>
                  <td style="width:100px;text-align:center;">132.30</td>
                </tr>
              </table>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq4">TERMS & CONDITIONS FOR ABOVE BAGS<i class="ion-android-remove"></i></a>
            <div id="faq4" class="collapse" data-parent="#faq-list">
              <ol>
                <li>Quantities will vary based on GSM, Given only approx Quantities</li>
                <li>50/100 % advance to be given according order</li>
                <li>Delivery with in 7-10 Days from the date order with advance</li>
                <li>Packing and forwarding charges extra</li>
              </ol>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq5">ALL CUT NON WOVEN BAGS - WHITE BAG PRINTING COST LIST<i class="ion-android-remove"></i></a>
            <div id="faq5" class="collapse" data-parent="#faq-list">
              <table class="table-bordered table-hover" width="100%" cellspacing="10" cellpadding="10">
                <tr style="background-color:#bfca33;">
                  <th style="width:100px;text-align:center;">Type</th>
                  <th style="text-align:center;">One Color One Side Printing Cost</th>
                  <th style="text-align:center;">One Color Two Side Printing Cost</th>
                  <th style="text-align:center;">One Side Double Color Printing Cost</th>
                  <th style="text-align:center;">Two Side Double Color Printing Cost</th>
                  <th style="text-align:center;">GSM</th>
                </tr>
                <tr>
                  <td style="text-align:center;">W CUT</td>
                  <td style="text-align:center;">Rs.147/Kg</td>
                  <td style="text-align:center;">Rs.155/Kg</td>
                  <td style="text-align:center;">Rs.167/Kg</td>
                  <td style="text-align:center;">Rs.180/Kg</td>
                  <td style="text-align:center;">45/50</td>
                </tr>
                <tr>
                  <td style="text-align:center;">U CUT</td>
                  <td style="text-align:center;">Rs.147/Kg</td>
                  <td style="text-align:center;">Rs.155/Kg</td>
                  <td style="text-align:center;">Rs.167/Kg</td>
                  <td style="text-align:center;">Rs.180/Kg</td>
                  <td style="text-align:center;">45/50</td>
                </tr>
                <tr>
                  <td style="text-align:center;">D CUT</td>
                  <td style="text-align:center;">Rs.150/Kg</td>
                  <td style="text-align:center;">Rs.160/Kg</td>
                  <td style="text-align:center;">Rs.170/Kg</td>
                  <td style="text-align:center;">Rs.185/Kg</td>
                  <td style="text-align:center;">60/80</td>
                </tr>
              </table>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq6">ALL CUT NON WOVEN BAGS - COLOR BAG PRINTING COST LIST<i class="ion-android-remove"></i></a>
            <div id="faq6" class="collapse" data-parent="#faq-list">
              <table class="table-bordered table-hover" width="100%" cellspacing="10" cellpadding="10">
                <tr style="background-color:#bfca33;">
                  <th style="width:100px;text-align:center;">Type</th>
                  <th style="text-align:center;">One Color One Side Printing Cost</th>
                  <th style="text-align:center;">One Color Two Side Printing Cost</th>
                  <th style="text-align:center;">One Side Double Color Printing Cost</th>
                  <th style="text-align:center;">Two Side Double Color Printing Cost</th>
                  <th style="text-align:center;">GSM</th>
                </tr>
                <tr>
                  <td style="text-align:center;">W CUT</td>
                  <td style="text-align:center;">Rs.151/Kg</td>
                  <td style="text-align:center;">Rs.165/Kg</td>
                  <td style="text-align:center;">Rs.170/Kg</td>
                  <td style="text-align:center;">Rs.185/Kg</td>
                  <td style="text-align:center;">45/50</td>
                </tr>
                <tr>
                  <td style="text-align:center;">U CUT</td>
                  <td style="text-align:center;">Rs.149/Kg</td>
                  <td style="text-align:center;">Rs.165/Kg</td>
                  <td style="text-align:center;">Rs.170/Kg</td>
                  <td style="text-align:center;">Rs.185/Kg</td>
                  <td style="text-align:center;">45/50</td>
                </tr>
                <tr>
                  <td style="text-align:center;">D CUT</td>
                  <td style="text-align:center;">Rs.160/Kg</td>
                  <td style="text-align:center;">Rs.170/Kg</td>
                  <td style="text-align:center;">Rs.180/Kg</td>
                  <td style="text-align:center;">Rs.195/Kg</td>
                  <td style="text-align:center;">60/80</td>
                </tr>
              </table>
            </div>
          </li>

          <li>
            <a data-toggle="collapse" class="collapsed" href="#faq7">TERMS & CONDITIONS FOR ABOVE PRINTING BAGS<i class="ion-android-remove"></i></a>
            <div id="faq7" class="collapse" data-parent="#faq-list">
              <ol>
                <li>GST extra 5%</li>
                <li>Coral draw design to be provided  by client</li>
                <li>Flexo stencil to be provided by client or we can  make it for the client in there expenses</li>
                <li>Packing cost - poly sacs of 50Kg/ 30Kg/ 10Kg</li>
              </ol>
            </div>
          </li>

        </ul>

      </div>
    </section>

    <!--==========================
      Call To Action Section
    ============================-->
    <section id="call-to-action" class="wow fadeInUp">
      <div class="container">
        <div class="row">
          <div class="col-lg-9 text-center text-lg-left">
            <h3 class="cta-title">Call To Action</h3>
            <p class="cta-text"> <b>Sudhaesh Shankar P (Managing Partner),</b><br> Mobile: +91 94881 92245, E-Mail: lyontek2017@gmail.com  <br>Door 14-B, SF 180-3C, AG Pudur Road, Irugur Post, Coimbatore-641103, Tamil Nadu, India.</p>
           
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#footer">Call To Action</a>
          </div>
        </div>

      </div>
    </section><!-- #call-to-action -->

    <!--==========================
      Portfolio Section
    ============================-->
    <section id="portfolio" class="section-bg">
      <div class="container">

        <header class="section-header">
          <h3 class="section-title">Gallery</h3>
        </header>

        <div class="row">
          <div class="col-lg-12">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">D CUT</li>
              <li data-filter=".filter-card">W CUT</li>
              <li data-filter=".filter-web">U CUT</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="img/portfolio/dcut1.jpeg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">D CUT</a></h4>
                <div>
                  <a href="img/portfolio/dcut1.jpeg" data-lightbox="portfolio" data-title="D CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="img/portfolio/dcut3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">D CUT</a></h4>
                <div>
                  <a href="img/portfolio/dcut3.jpg" data-lightbox="portfolio" data-title="D CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="img/portfolio/dcut4.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">D CUT</a></h4>
                <div>
                  <a href="img/portfolio/dcut4.jpg" data-lightbox="portfolio" data-title="D CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="img/portfolio/dcut5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">D CUT</a></h4>
                <div>
                  <a href="img/portfolio/dcut5.jpg" data-lightbox="portfolio" data-title="D CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="img/portfolio/ucut2.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">U CUT</a></h4>
                <div>
                  <a href="img/portfolio/ucut2.jpg" data-lightbox="portfolio" data-title="U CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="img/portfolio/ucut3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">U CUT</a></h4>
                <div>
                  <a href="img/portfolio/ucut3.jpg" data-lightbox="portfolio" data-title="U CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="img/portfolio/ucut4.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">U CUT</a></h4>
                <div>
                  <a href="img/portfolio/ucut4.jpg" data-lightbox="portfolio" data-title="U CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="img/portfolio/ucut5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">U CUT</a></h4>
                <div>
                  <a href="img/portfolio/ucut5.jpg" data-lightbox="portfolio" data-title="U CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="img/portfolio/wcut1.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">W CUT</a></h4>
                <div>
                  <a href="img/portfolio/wcut1.jpg" data-lightbox="portfolio" data-title="W CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="img/portfolio/wcut2.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">W CUT</a></h4>
                <div>
                  <a href="img/portfolio/wcut2.jpg" data-lightbox="portfolio" data-title="W CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="img/portfolio/wcut5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">W CUT</a></h4>
                <div>
                  <a href="img/portfolio/wcut5.jpg" data-lightbox="portfolio" data-title="W CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="img/portfolio/wcut6.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">W CUT</a></h4>
                <div>
                  <a href="img/portfolio/wcut6.jpg" data-lightbox="portfolio" data-title="W CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="img/portfolio/wcut7.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><a href="#">W CUT</a></h4>
                <div>
                  <a href="img/portfolio/wcut7.jpg" data-lightbox="portfolio" data-title="W CUT" class="link-preview" title="Preview"><i class="ion ion-eye"></i></a>
                  <a href="#" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- #portfolio -->

    <!--==========================
      Clients Section
    ============================-->
    <section id="testimonials">
      <div class="container">

        <header class="section-header">
          <h3>Our Valuable Clients</h3>
        </header>

        <div class="row justify-content-center">
          <div class="col-lg-8">

            <div class="owl-carousel testimonials-carousel wow fadeInUp">
    
              <div class="testimonial-item">
                <h3>Elite Trading Company</h3>
                <h4>Calicut, Kerala</h4>
              </div>
    
              <div class="testimonial-item">
                <h3>Orchid Bags</h3>
                <h4>Thrissur, Kerala</h4>
              </div>
    
              <div class="testimonial-item">
                <h3>Umakanth Madhukar Nawale</h3>
                <h4>Nasik, Maharashtra</h4>
              </div>
    
              <div class="testimonial-item">
                <h3>Village Printed Carry Bags</h3>
                <h4>Ernakulam, Kerala</h4>
              </div>

              <div class="testimonial-item">
                <h3>Saurastra Stores</h3>
                <h4>Sangli, Maharashtra</h4>
              </div>
              <div class="testimonial-item">
                <h3>Sri Kiruba Bags House</h3>
                <h4>Nasik, Maharashtra</h4>
              </div>
              <div class="testimonial-item">
                <h3>SMS Chicken Lounge</h3>
                <h4>Dum Duma, Odisha</h4>
              </div>
              <div class="testimonial-item">
                <h3>Rangoli Creation</h3>
                <h4>Pune, Maharashtra</h4>
              </div>
              <div class="testimonial-item">
                <h3>Ankush Agarwal</h3>
                <h4>Nagpur, Maharashtra</h4>
              </div>
              <div class="testimonial-item">
                <h3>Mr.J.Prasad</h3>
                <h4>Ongole, Andhra Pradesh</h4>
              </div>
              <div class="testimonial-item">
                <h3>Shivasakthi Enterprises</h3>
                <h4>Cuttack, Odisha</h4>
              </div>
              <div class="testimonial-item">
                <h3>Navaree Engineers</h3>
                <h4>Ayanavaram, Chennai</h4>
              </div>
              <div class="testimonial-item">
                <h3>Nataraja Power Tools</h3>
                <h4>Coimbatore</h4>
              </div>
              <div class="testimonial-item">
                <h3>Sree Sai Enterprises</h3>
                <h4>Thiruvallur</h4>
              </div>

            </div>

          </div>
        </div>


      </div>
    </section><!-- #testimonials -->



  </main>

  <!--==========================
    Footer
  ============================-->
  <footer id="footer" class="section-bg">
    <div class="footer-top">
      <div class="container">

        <div class="row">

          <div class="col-lg-6">

            <div class="row">

                <div class="col-sm-6">

                  <div class="footer-info">
                    <h3>LYONTEK</h3>
                    <p style="text-align:justify;">Since 2017, we “Lyontek” is working as a Partnership based entity, which frequently put efforts to offer the qualitative array of products to the market. We set our chief to headquarter at Irugur Post, Coimbatore, Tamil Nadu. Our manufacturing occupation runs under the keen surveillance of our professional and our products widely rejoice amongst the customers. Due to our in-depth acquaintance of this domain, we are delivering the spectrum of products includes Non-Woven Bag and many more.</p>
                  </div>

                </div>

                <div class="col-sm-6">
                  <div class="footer-links">
                    <h4>Useful Links</h4>
                    <ul>
                      <li><a href="#intro">Home</a></li>
                      <li><a href="#about">About us</a></li>
                      <li><a href="#services">Our Infrastructure</a></li>
                      <li><a href="#features">Products</a></li>
                      <li><a href="#portfolio">Gallery</a></li>
                    </ul>
                  </div>

                  <div class="footer-links">
                    <h4>Contact Us</h4>
                    <p>
                      <b>Address:</b><br>
                      Door 14-B, SF 188-3C,<br>
                      AG Pudur Road, Irugur Post,<br>
                      Coimbatore-641103, Tamil Nadu, India<br>
                      <strong>Phone:</strong>+91 8048733088<br>
                      <strong>Email:</strong> lyontek2017@gmail.com<br>
                    </p>
                  </div>

                  <div class="social-links">
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                  </div>

                </div>

            </div>

          </div>

          <div class="col-lg-6">

            <div class="form">
              
              <h4>Tell Us What Are You Looking For</h4>
              <form action="mail.php" method="post" role="form" class="">
                <div class="form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                  <div class="validation"></div>
                </div>

                <div id="sendmessage">Your message has been sent. Thank you!</div>
                <div id="errormessage"></div>

                <div class="text-center"><input type="submit" name="submit" class="btn-primary btn" value="Send Message"/></div>
              </form>
            </div>

          </div>

          

        </div>

      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>LYONTEK</strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Rapid
        -->
        Designed by <a href="https://www.boopalan.saznotes.co.in" target="_blank">SB</a>
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/mobile-nav/mobile-nav.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
